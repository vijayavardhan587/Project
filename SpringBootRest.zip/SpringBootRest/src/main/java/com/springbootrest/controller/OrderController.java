package com.springbootrest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springbootrest.entity.Order1;
import com.springbootrest.entity.OrderWrapper;
import com.springbootrest.service.OrderService;

@RestController
@RequestMapping("/order")
public class OrderController {

	@Autowired
	OrderService ser;
	
	@PostMapping("/placeorder")
	public ResponseEntity<OrderWrapper> placeOrder(@RequestParam int id,int qty) {
	return	ser.placeOrder(id,qty);
	}
}
