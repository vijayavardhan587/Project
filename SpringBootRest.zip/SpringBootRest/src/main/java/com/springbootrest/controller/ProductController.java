package com.springbootrest.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springbootrest.dto.ProductDto;
import com.springbootrest.entity.Product;
import com.springbootrest.service.ProductService;
import com.springbootrest.service.ResponceClass;

@RestController
@RequestMapping("/product") // its used to mapped url
public class ProductController {

	// @requestBody ->its used to send the data from client to service
	// @pathvariable ->its used to send the data through url path from client to
	// service
	// @RequestBody its used to send request along with data
	ProductService prductservice;

	@Autowired
	public ProductController(ProductService prductservice) {
		this.prductservice = prductservice;
	}
//end point url->/addproduct,/showproduct,/deleteproduct,/updateproduct

	@PostMapping("/addproduct") // used to insert the row in table end point url
	public ResponseEntity<Product> addProduct(@RequestBody Product p) {
		Product p1 = prductservice.addProduct(p);
		return ResponseEntity.ok(p1);

	}

	@GetMapping("/showproduct") // used to read the row from table end point url
	public ResponseEntity<List<Product>> showProduct() {
		List<Product> list = prductservice.showProduct();
		return ResponseEntity.ok(list);

	}

	@GetMapping("/getproduct/{id}")
	public Optional<Product> getproductbyid(@PathVariable int id) {
		Optional<Product> op = prductservice.getproductbyid(id);
		return op;
	}

	@DeleteMapping("/deleteproduct/{id}")
	public String deletedById(@PathVariable int id) {
		ResponceClass p = prductservice.deleteById(id);

		if (p.getProduct() == null) {
			return p.getErrormsg();
		}
		return p.getMsg();
	}

	// ResponseEntity is used to return the responce along with http status
	@GetMapping("/getproductbyprice/{price}")
	public ResponseEntity<List<Product>> getProductByPrice(@PathVariable int price) {
		return new ResponseEntity<>(prductservice.getProductByPrice(price), HttpStatus.OK);
	}
	
	 @PutMapping("/updateproduct/{id}")
	 public Product updateproduct(@PathVariable  int id,@RequestBody Product newproduct) {
		return prductservice.updateProduct(id,newproduct);
	 }
}
