package com.springbootrest.dto;

public class ProductDto {
    private String pname;
    private String price;

    public ProductDto(String pname, String price) {
        this.pname = pname;
        this.price = price;
    }

    public String getPname() {
        return pname;
    }

    public String getPrice() {
        return price;
    }
}

