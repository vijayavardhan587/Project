package com.springbootrest.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.springbootrest.entity.Order1;
import com.springbootrest.entity.OrderWrapper;
import com.springbootrest.entity.Product;
import com.springbootrest.repository.OrderRepository;
import com.springbootrest.repository.ProductRepository;

@Service
public class OrderService {

	@Autowired
	OrderRepository orderrepo;

	@Autowired
	ProductRepository prepo;

	public ResponseEntity<OrderWrapper> placeOrder(int id, int qty) {
		Optional<Product> p = prepo.findById(id);
		// check product is available
		if (p.isPresent()) {
			Product p1 = p.get();
			// chek the qty in product
			if(p1.getQuantity()>= qty) {
				// create the new order and set the value
				// product ,qty,totle price,status
				Order1 o = new Order1();
				o.setProduct(p1);
				o.setQty(qty);
				o.setStatus("placed");
				o.setTotalPrice(p1.getPrice()*qty);
				p1.setQuantity(p1.getQuantity()-qty);
				orderrepo.save(o);
				// return the string that order placed
				OrderWrapper ow = new OrderWrapper(o.getOid(),
						o.getTotalPrice(), o.getQty(), o.getStatus(),
						o.getProduct().getPname());
				return ResponseEntity.ok(ow);
			}else {
				throw new RuntimeException("stock unavailable");
			}

		}else {
			throw new RuntimeException("product is not available");
		}
		
	}

}
