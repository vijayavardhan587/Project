package com.springbootrest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbootrest.dto.ProductDto;
import com.springbootrest.entity.Product;
import com.springbootrest.repository.ProductRepository;

@Service
public class ProductService {

	private ProductRepository productRepo;

	@Autowired
	public ProductService(ProductRepository productRepo) {
		this.productRepo = productRepo;
	}

	public Product addProduct(Product p) {
		return productRepo.save(p);
	}

	public List<Product> showProduct() {

		List<Product> list = productRepo.findAll();
		return list;

	}

	public Optional<Product> getproductbyid(int id) {
		Optional<Product> op = productRepo.findById(id);// if data is not exist if use getbyid then nullpointer
														// exception
		if (op.isPresent()) {
			return op;
		} else {
			return null;
		}

	}

	public ResponceClass deleteById(int id) {
		Optional<Product> p = productRepo.findById(id);
		if (p.isPresent()) {
			productRepo.deleteById(id);
			return new ResponceClass("product has been deleted", p.get(), null);
		} else {
			return new ResponceClass(null, null, +id + " id is not valid");
		}
	}

	public List<Product> getProductByPrice(int price) {
		return productRepo.getProductByPrice(price);

	}

	public Product updateProduct(int id, Product newproduct) {
		Optional<Product> p = productRepo.findById(id);
		
		if (p.isPresent()) {
			Product p1 = p.get();
			p1.setPname(newproduct.getPname());
			p1.setPrice(newproduct.getPrice());
			p1.setQuantity(newproduct.getQuantity());
			return productRepo.save(p1);
		} else {
			throw new RuntimeException("invalid product id");
		}

	}

}
