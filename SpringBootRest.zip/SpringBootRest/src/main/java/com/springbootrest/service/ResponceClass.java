package com.springbootrest.service;

import com.springbootrest.entity.Product;

public class ResponceClass {
 String msg;
 Product product;
 String errormsg;
public ResponceClass(String msg, Product product, String errormsg) {
	super();
	this.msg = msg;
	this.product = product;
	this.errormsg = errormsg;
}

public ResponceClass(Product product, String errormsg) {
	super();
	this.product = product;
	this.errormsg = errormsg;
}
public ResponceClass(String msg, String errormsg) {
	super();
	this.msg = msg;
	this.errormsg = errormsg;
}
public ResponceClass(String msg, Product product) {
	super();
	this.msg = msg;
	this.product = product;
}
public String getMsg() {
	return msg;
}
public void setMsg(String msg) {
	this.msg = msg;
}
public Product getProduct() {
	return product;
}
public void setProduct(Product product) {
	this.product = product;
}
public String getErrormsg() {
	return errormsg;
}
public void setErrormsg(String errormsg) {
	this.errormsg = errormsg;
}

 
}
